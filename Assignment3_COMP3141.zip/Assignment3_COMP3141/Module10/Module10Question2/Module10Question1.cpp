#include <string>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstdlib>
#include "ClientData.h" // ClientData class definition
#include "ClientData.cpp"
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */
using namespace std;
void displayMenu();
void randomFile();
void sequentialFile();
void menuSelection(int);
string filename;
void outputLine( int acct, const char *name, double bal );
int selection;
void createFile();
void outputLine( ostream&, const ClientData & ); // prototype
int main()
{
   do{
        displayMenu();
    }while(selection!= 5);

}
void outputLine( ostream &output, const ClientData &record )
{
   output << left << setw( 10 ) << record.getAccountNumber()
      << setw( 16 ) << record.getLastName()
      << setw( 11 ) << record.getFirstName()
      << setw( 10 ) << setprecision( 2 ) << right << fixed
      << showpoint << record.getBalance() << endl;
} // end function outputLine
// end while

void outputLine( int acct, const char *name, double bal )
{ cout << setiosflags( ios::left ) << setw( 10 ) << acct
<< setw( 13 ) << name << setw( 7 ) << setprecision( 2 ) << resetiosflags(
ios::left ) << setiosflags( ios::fixed | ios::showpoint ) << bal << '\n';
}

void sequentialFile()
{

    string input;
    string filename;
    ifstream inClientFile;

    cout<<"which file do you want to open?";
    cin>>filename;

    inClientFile.open(filename.c_str());


//    ifstream inClientFile( "credit2.dat", ios::in);

   // exit program if ifstream cannot open file
   if ( !inClientFile )
   {
      cerr << "File could not be opened." << endl;
      exit(1);
   } // end if

   int account;
    char name[ 300 ];
    double balance;
    cout << setiosflags( ios::left ) << setw( 10 ) << " "
    << setw( 13 ) << " " << " \n";
    while ( inClientFile >> account >> name >> balance )
          outputLine( account, name, balance );


}

void writeToRandom() {

    string filename;
    ofstream outCredit;

    cout<<"which file do you want to write to?";
    cin>>filename;
    outCredit.open(filename.c_str());

   if ( !outCredit )
   {
      cerr << "File could not be opened." << endl;
      exit( EXIT_FAILURE );
   } // end if
       char input[250];
       cout << "\nEnter what you would like to write:";
       cin >> input;

    outCredit.write(reinterpret_cast<char *> (&input),sizeof(input));
   // bin.write(reinterpret_cast<char *> (&ch),sizeof(ch));
  //outCredit << input << " " << endl;

  outCredit.close();
}
void randomFile()
{
    string input;
    string filename;
    ifstream inCredit;

    cout<<"which file do you want to open?";
    cin>>filename;

    inCredit.open(filename.c_str());

    //fstream inCredit( "credit.dat", ios::in | ios::binary );
   if ( !inCredit )
   {
      cerr << "File could not be opened." << endl;
      exit( EXIT_FAILURE );
   } // end if
/*
    inCredit.read(input, 100);
   //inCredit.read(input, 250);
//   inCredit.read( reinterpret_cast< char * >(input),250);

     cout << left << setw( 10 ) << "Account" << setw( 16 )
      << "Last Name" << setw( 11 ) << "First Name" << left
      << setw( 10 ) << right << "Balance" << endl;

         outputLine( cout, input);
    while ( inCredit && !inCredit.eof() )
       {
          // display record
             outputLine( cout, input );

          // read next from file
           inCredit.read(input, 100);

       }

    //inCredit.read(input, 250);
    //cout << left << setw( 10 ) << "  " << setw( 16 )
      //<< " " << setw( 11 ) <<  " " << left
      //<< setw( 10 ) << right << "  " << endl;
/*
   inCredit.seekg (0,inCredit.end);
  long size = inCredit.tellg();
  inCredit.seekg (0);

  // allocate memory for file content
  char* buffer = new char[size];

  // read content of infile
  inCredit.read(buffer,size);
inCredit.close();

  /*
      cout << left << setw( 10 ) << "  " << setw( 16 )
      << "Last Name" << setw( 11 ) <<  " " << left
      << setw( 10 ) << right << "  " << endl;

   // read first record from file
   inCredit.read( &input, sizeof( input[250] ) );
*/
   // read all records from file

      /*
   ClientData client; // create record

   inCredit.seekg(sizeof(ClientData)*(num-1), ios::beg);
   // read first record from file
   inCredit.read( reinterpret_cast< char * >( &client ),
      sizeof( ClientData ) );
     cout << left << setw( 10 ) << "Account" << setw( 16 )
      << "Last Name" << setw( 11 ) << "First Name" << left
      << setw( 10 ) << right << "Balance" << endl;

         outputLine( cout, client );
         */


}

void displayMenu() {
    cout << "\nMenu \n" << "Enter 1 to Create Random File \n" << "Enter 2 to Read Random Access File \n"
        << "Enter 3 to Read Sequental File  \n" << "Enter 4 to Write to File \n" << "Enter 5 to Quit. \n";
    cin >>  selection;
    menuSelection(selection);
}

void createFile() {

  ofstream f;
  std::cin.ignore( std::numeric_limits<std::streamsize>::max(), '\n' );
  cout << "Please enter a file name to write: ";
  getline( cin, filename );
  f.open( filename.c_str() );
  f << "\n";
  f.close();
  cout << " " << endl;
}
void menuSelection(int i) {
    int m;
    switch(i) {
        case 1:
            cout << "\nCreate Random File!\n";
            createFile();
            break;
        case 2:
            cout << "Read Random Access File \n";
            randomFile();
            break;
        case 3:
                cout << "Read Sequental Access\n";
                sequentialFile();
                break;
        case 4:
              cout << "Write to File!\n";
              writeToRandom();
              break;
        case 5:
            exit(0);
        default:
            cout << "Please Enter a Valid Menu Value: ";
            cin >> m;
    }
}
