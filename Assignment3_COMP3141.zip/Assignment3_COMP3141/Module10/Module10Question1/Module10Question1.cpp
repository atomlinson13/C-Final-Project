
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstdlib>
#include "ClientData.h" // ClientData class definition
#include "ClientData.cpp"
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */
using namespace std;

void outputLine( ostream&, const ClientData & ); // prototype
int main()
{
  srand (time(NULL));
   int num = rand() % 10 + 1;

   fstream inCredit( "credit.dat", ios::in | ios::binary );

   // exit program if ifstream cannot open file
   if ( !inCredit )
   {
      cerr << "File could not be opened." << endl;
      exit( EXIT_FAILURE );
   } // end if

   ClientData client; // create record

   inCredit.seekg(sizeof(ClientData)*(num-1), ios::beg);
   // read first record from file
   inCredit.read( reinterpret_cast< char * >( &client ),
      sizeof( ClientData ) );
     cout << left << setw( 10 ) << "Account" << setw( 16 )
      << "Last Name" << setw( 11 ) << "First Name" << left
      << setw( 10 ) << right << "Balance" << endl;

         outputLine( cout, client );
}
void outputLine( ostream &output, const ClientData &record )
{
   output << left << setw( 10 ) << record.getAccountNumber()
      << setw( 16 ) << record.getLastName()
      << setw( 11 ) << record.getFirstName()
      << setw( 10 ) << setprecision( 2 ) << right << fixed
      << showpoint << record.getBalance() << endl;
} // end function outputLine
// end while
