// Fig. 11.9: fig11_09.cpp
// Testing class BasePlusCommissionEmployee.
#include <iostream>
#include <iomanip>
#include "BasePlusCommissionEmployee.cpp" // class definition
#include "BasePlusCommissionEmployee.h" // class definition
#include "CommissionEmployee.h" // class definition
#include "CommissionEmployee.cpp" // class definition

using namespace std;

int main()
{

   CommissionEmployee employee2("Jennifer", "Buckles", "123-13-1233", 10000, .10);

   BasePlusCommissionEmployee employee( "Bobbie", "Lewis", "333-33-3333", 5000, .04, 300);




   cout << fixed << setprecision( 2 );

   cout << "Employee information obtained by get functions: \n"
      << "First name is " << employee.getFirstName()
      << "\nLast name is " << employee.getLastName()
      << "\nSocial security number is "
      << employee.getSocialSecurityNumber()
      << "\nGross sales is " << employee.getGrossSales()
      << "\nCommission rate is " << employee.getCommissionRate()
      << "\nBase salary is " << employee.getBaseSalary() << endl;

      employee.setBaseSalary( 1000 ); // set base salary

   cout << "\nUpdated employee information output by print function: \n"
      << endl;
   employee.print(); // display the new employee information
   cout << "\n\n";
   employee2.print();
   // display the employee's earnings
   cout << "\n\n" << employee.getFirstName() << " earnings: $" << employee.earnings() << endl;
   cout << "" << employee2.getFirstName() << " earnings: $" << employee2.earnings() << endl;


} // end main

// TODO - Add an object of CommissionEmployee
// Run the print method of CommissionEmployee


