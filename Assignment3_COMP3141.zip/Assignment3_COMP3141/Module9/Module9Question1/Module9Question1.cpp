#include <iostream>
#include <iomanip>
#include <vector>
#include <typeinfo>
#include <cstddef>
#include "Employee.cpp"
#include "HourlyEmployee.cpp"
#include "SalariedEmployee.cpp"
#include "BasePlusCommissionEmployee.cpp" // class definition
#include "CommissionEmployee.cpp" // class definition
#include <iostream>
#include <string>
#include <stdlib.h>
#include <typeinfo>
int main()
{
       vector <Employee*> employees(4);
       employees[0] = new SalariedEmployee("John", "Smith", "111-11-1111", 800 );
       employees[1] = new CommissionEmployee("Sue", "Jones","333-33-3333", 10000, .06 );
       employees[2] = new HourlyEmployee("John", "Charles", "111-11-1111", 26, 80 );
       employees[3] = new BasePlusCommissionEmployee("Bob", "Lewis", "444-44-4444", 5000, .04, 300 );

       for( int i = 0; i < employees.size(); i++)
       {


         HourlyEmployee *derivedPtr = dynamic_cast < HourlyEmployee * >( employees[i] );

        if ( derivedPtr != 0) // true for "is a" relationship
        {

            double oldRate = derivedPtr->getWage(); // get the old salary
            cout << "Old Hourly Rate: $" << oldRate << endl; //print old salary
            derivedPtr->setWage((.10*oldRate) + oldRate); // provide a 10% raise
            cout << "New Hourly Rate with 10% increase is: $" << derivedPtr->getWage() << "" << endl; // get the new salary


        } // end if

         employees[i]->print();
         cout << "\nEarnings: " << employees[i]->earnings() << "\n\n";


       }

}
//@ STUDENT TO DO : Change the Hourly rate of the Hourly Employee and give 10% increase in houlry rate
