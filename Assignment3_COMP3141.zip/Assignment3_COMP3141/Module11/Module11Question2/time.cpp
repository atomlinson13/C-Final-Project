#include <ctime>
#include<iostream>
#include "time.h"
using namespace std;

Date::Date(const int a, const int b, const int c)
    : year(a),
      month(b),
      day(c)
{

}

void Date::setBirthday(int y, int m, int d)
{
 year = y;
 month = m;
 day = d;
}




void Date::setDay(int d)
{
	if (d < 1 && d > 31)
		cout << "The day is invalid" << endl;
	else
	day = d;

}
void Date::setMonth(int m)
{
	if (m < 1 && m > 12)
		cout << "The month is invalid" << endl;
	else
	month = m;

}

int Date::getMonth()
{
	return month;
}

void Date::setYear(int y)
{
	if (y < 1950 && y > 2020)
		cout << "The year is invalid" << endl;
	else
		year = y;
}


void Date::print() const
{
cout << " " << year <<"/" << month << "/" << day;

}


int Date::operator- (const Date &right)
{
	int jDate1;
	int jDate2;
	int newDate;
	jDate1 = (1461 * (year + 4800 + (month - 14)/12))/4 +(367 * (month - 2 - 12 * ((month - 14)/12)))/12 - (3 * ((year + 4900 + (month - 14)/12)/100))/4 + day - 32075;
	jDate2 = (1461 * (right.year + 4800 + (right.month - 14)/12))/4 +(367 * (right.month - 2 - 12 * ((right.month - 14)/12)))/12 - (3 * ((right.year + 4900 + (right.month - 14)/12)/100))/4 + right.day - 32075;
	newDate = jDate1 - jDate2;
	return newDate;
}


