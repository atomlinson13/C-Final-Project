#include <iostream>
#include <iomanip>
#include <vector>
#include <typeinfo>
#include <cstddef>
#include "Employee.cpp"
#include "HourlyEmployee.cpp"
#include "SalariedEmployee.cpp"
#include "BasePlusCommissionEmployee.cpp" // class definition
#include "CommissionEmployee.cpp" // class definition
#include <iostream>
#include <string>
#include <stdlib.h>
#include <ctime>
#include "time.h"
#include <exception>

using namespace std;

    time_t timeinfo = time(0);
    struct tm localt = *localtime(&timeinfo);
    int year = localt.tm_year+1900;
    int month = localt.tm_mon+1;
    int day = localt.tm_mday;
    Date today(year, month, day);

    class Birthday : public exception{
    int birthdayParty;
    public :
    const char* what(){
    return "Happy Birthday!!!"; }
    };
int main()
{
       vector <Employee*> employees(4);
       employees[0] = new SalariedEmployee("John", "Smith", "111-11-1111", 800 );
       employees[0]-> setBirthday(1993,3,9);
       employees[1] = new CommissionEmployee("Sue", "Jones","333-33-3333", 10000, .06 );
       employees[1]-> setBirthday(2000,12,21);
       employees[2] = new HourlyEmployee("John", "Charles", "111-11-1111", 26, 80 );
       employees[2]-> setBirthday(1990,1,14);
       employees[3] = new BasePlusCommissionEmployee("Bob", "Lewis", "444-44-4444", 5000, .04, 300 );
       employees[3]-> setBirthday(1995,2,22);
       int month = today.getMonth();



       for( int i = 0; i < employees.size(); i++)
       {
         int bday = employees[i]->getBirthdayMonth();

          try
           {
                      if(month == bday) {
                          employees[i]->setBonus(100);
                          Birthday b;
                          throw b;
                      }
           }
           catch (Birthday b)
            {
                cout << b.what() <<endl;
            }


         employees[i]->print();
         cout << "\nEarnings: " << employees[i]->earnings() << "\n\n";
       }

}

