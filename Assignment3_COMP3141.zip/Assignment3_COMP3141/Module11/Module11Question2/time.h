#ifndef TIME_H_INCLUDED
#define TIME_H_INCLUDED

class Date {

private:
	int day;
	int month;
	int year;
public:
	Date(const int a, const int b, const int c);
	void setBirthday(int y, int m, int d);
	void setDay(int d);
	int getMonth();
	void setMonth(int d);
	void setYear(int d);
	void print() const;
    int operator-(const Date &b);
   // ~Date();
};
#endif // TIME_H_INCLUDED
